#!/usr/bin/env python
# Coding = UTF-8

"""
	This module contains functions exclusively to interact with Jira.
"""