#!python
# Coding: UTF-8

# Header
"""
    Description:
    This script's intent is to update usernames between Confluence instances.
    First step is to pull usernames out of a Confluence space's XML
    export and save them to a CSV file. Then that file can then be updated by
    the program and run through this script again to find and replace the
    old usernames with the new target instances usernames. Additionally
    you will be asked if you would like to update the space's key.
    
    Args:
    --url: Enter the url for the target instance of Confluence. This
         will allow the script to populate the user's full name from
        Confluence into the CSV user table. If exporting from an SDTEOB
        instance, you may enter "dev", "pre", or "prod".
            
    --csv: User's table in CSV format. Do not specify this until the import
        step. All users in the CSV output from the --XML file should have
        a target username and key before using this option.
            
    --xml: XML file input. This is the result of a Confluence space export.
        This file will be updated with new usernames/keys from the CSV.
            
    --cert: Certifiacte for confluence validation. If not provided SSL Verify
        will be set to False.
"""

__copyright__ = 'Boeing (C) 2021, All rights reserved'
__license__ = 'proprietary'
# [...]


# Imports - Standard Library
import argparse
import logging
import os
import sys
import time

# Imports - 3rd Party
# Import and modify a progress bar for windows
import patched_progress
progress = patched_progress.getpatchedprogress()
from progress.bar import IncrementalBar

# Imports - Local
import confluence_interface


# Configure logging
log_format = "%(asctime)s - %(levelname)s - %(module)s:%(funcName)s:%(lineno)d - %(message)s"
log_filename = (__file__.split('\\')[-1]).split('.')[0] # Filename of current script minus extension
logging.basicConfig(level='INFO', format=log_format, filename='{}.log'.format(log_filename))
log = logging.getLogger(__name__)


if __name__ == '__main__':
    # Metrics - Start time
    start_time = time.time()
    
    args = confluence_interface.get_user_input()

    # # Parse command line arguments
    # parser = argparse.ArgumentParser(
    #     description = 'Scripted interaction with a Confluence instance.'
    #     )
    # parser.add_argument(
    #     '--url', 
    #     help = 'Specify the URL of your Confluence instance. If SDTEOB enter "dev", "pre", or "prod".',
    #     action = 'store',
    #     dest = 'url',
    #     required=True
    #     )
    # parser.add_argument(
    #     '--csv', 
    #     help = 'CSV input file. This is performed on the the target ' +
    #     'instance. The XML argument must also be provided.',
    #     action = 'store',
    #     dest = 'csv'
    #     )      
    # parser.add_argument(
    #     '--xml',
    #     help = 'XML input file. This is performed on the source instance.', 
    #     action = 'store',
    #     dest = 'xml'
    #     )
    # parser.add_argument(
    #     '--cert',
    #     help = 'Certificate for HTTP authorization.', 
    #     action = 'store',
    #     dest = 'cert'
    #     )   
    # args = parser.parse_args()
    
    # Validate certificate file exists
    if not args.cert is None:
        if not os.path.exists(args.cert):
            print('Certificate file not found. Validation will be disabled.')
            args.cert = False
    else:
        args.cert = False

    # Request credentials
    credentials = confluence_interface.get_credentials()

    # Establish http session
    http_session = confluence_interface.set_http_session(args.url, credentials, args.cert)

    # Read XML
    xml_data = None
    if not args.xml is None:
        if os.path.exists(args.xml):
            xml_data = confluence_interface.read_xml(args.xml)
        else:
            sys.exit('XML file not found, aborting.')

    # Update usernames and keys
    remap = False
    users_dict = {}
    if confluence_interface.ask_yes_no(
        'Do you have a user csv table? (Y/N): '
        ):
        # Get file from user and add to args namespace
        args.csv = confluence_interface.get_file('Select Users.csv', [['CSV files', '*.csv']])
        # Update user entries
        users_dict = confluence_interface.read_users_from_csv(args.csv)
    else:
        users_dict = confluence_interface.read_users_from_xml(xml_data)
        # Write user dictionary to csv
        confluence_interface.dict_to_csv(users_dict, args.xml, 'UserTable')
        confluence_interface.output_info('User table created at: {}' \
            .format(os.path.split(args.xml)[0]))
        confluence_interface.finish_message(start_time)
        sys.exit("Please fill out the user table the re-run this script.")

    change_count = 0 # Count changes as modify flag so we don't re-write file each run.
    if len(users_dict) > 0:
        # Get user data from target Confluence and update dictionary
        count = len(users_dict)
        progress_bar = IncrementalBar('Reading user data from CSV', max=len(users_dict))
        for user in users_dict:
            if (users_dict[user].get('target_username') != '') and (users_dict[user].get('target_key') == ''):
                log.info('Updating user {} => {}' \
                    .format(user, users_dict[user].get('target_username'))
                    )
                user_temp = confluence_interface.get_user_info(
                    http_session,
                    args.url,
                    user,
                    users_dict[user],
                    'username'
                    )
                if not user_temp is None:
                    users_dict[user] = user_temp
                    change_count += 1
            progress_bar.next()
        progress_bar.finish()
    
    # Write csv
    if change_count > 0:
        confluence_interface.dict_to_csv(users_dict, args.csv)
        
        # Process XML content
        answer = confluence_interface.ask_yes_no(
            'Use remap_user for blank usernames? If no, you must create users before continuing.(Y/N): '
            )
        xml_data = confluence_interface.replace_user_elements(
            xml_data,
            '//object[@class=\"ConfluenceUserImpl\"]',
            users_dict,
            answer
            )
        xml_data = confluence_interface.update_user_key_elements(
            xml_data,
            '//id[@name=\"key\"]',
            users_dict,
            answer
            )
        xml_data = confluence_interface.replace_mention(
            xml_data,
            '//property[@name=\"body\"]',
            users_dict
            )
        # xml_data = confluence_interface.replace_links(
        #     xml_data,
        #     '//property[@name=\"body\"]',
        #     server
        # )
        xml_data = confluence_interface.update_cdata_elements(xml_data)
        xml_data = confluence_interface.remove_duplicate_users(xml_data)
        xml_data = confluence_interface.xml_cleanup(xml_data)

    # Rekey space
    rekey = confluence_interface.ask_yes_no('Would you like to change this space\'s key? (Y/N): ')
    if rekey:
        xml_data = confluence_interface.replace_space_key(xml_data, args.xml)
        confluence_interface.write_descriptor_file(xml_data, args.xml)
    
    # One common import problem is the inablility to modify permissions after import. I'm fairly
    # certain this is due to the page restrictions, so we'll remove them.
    answer = confluence_interface.ask_yes_no('Remove content restrictions (Recommended)? (Y/N): ')
    if answer:
        confluence_interface.output_info('Removing content restrictions.')
        xml_data = confluence_interface.remove_page_restrictions(xml_data)
    
    # Create new xml file for import
    confluence_interface.write_xml(xml_data, args.xml)            
                
    # Metrics - Stop time and display elapsed
    confluence_interface.finish_message(start_time)
