#!python
"""Confluence import module for SDTEOB"""


# Imports - Standard Library
import colorama
import csv
import base64
import getpass
import glob
import http
import json
import logging
import os
import sys
import time
import types

# Imports - 3rd party
import requests
from requests.exceptions import ConnectionError
# Supress errors when certificate is not provided
from urllib3 import disable_warnings
from urllib3.exceptions import InsecureRequestWarning
from lxml import etree
# Import and modify a progress bar for windows
from patched_progress import getpatchedprogress
progress = getpatchedprogress()
from progress.bar import IncrementalBar


# Global variables
processed_target_keys = []


# Configure logging
log = logging.getLogger(__name__)


INFO = 'INFO'
WARNING = 'WARNING'
ERROR = 'ERROR'

SERVER_NAME_INDEX = 0
SERVER_URL_INDEX = 1
JIRA_PRODUCTION = ['SDTE Production', 'https://confluence-sdteob.web.boeing.com']
JIRA_PREPRODUCTION = ['SDTE Pre-Production', 'https://confluence-sdteob-pp.web.boeing.com']
JIRA_DEVELOPMENT = ['SDTE Development', 'https://confluence-sdteob-dev.web.boeing.com']
JIRA_MONARCH = ['SDTE Monarch', 'https://confluence.monarch.altitude.cloud']
JIRA_DEVSTACK = ['DevStack', 'https://devstack.ds.boeing.com/jira']


# Functions
def get_user_input() -> types.SimpleNamespace:
    """
    Get required information to start migration.
        * Conlfuence export
        * Source server url
        * Certificate file (Optional)

    Returns:
        dict: {'file':'', 'url':'', 'cert':''}
    """

    # Get csv file and validate path
    filename = ''
    while not os.path.exists(filename):
        print('Select your entities.xml file: ')
        filename = get_file('Select your entities.xml file', [['XML files', '*.xml']])

    # Get server url and verify it is reachable
    url = None
    while not validate_url(url, None):
        title = 'Jira Servers'
        columns = ['#', 'Name', 'URL']
        option_other = ['OTHER', 'Enter your own URL']
        url_list = [JIRA_MONARCH, JIRA_PRODUCTION, JIRA_PREPRODUCTION, JIRA_DEVELOPMENT, JIRA_DEVSTACK, option_other]
        count = 1
        dataset = []
        for server in url_list:
            dataset.append([count, server[SERVER_NAME_INDEX], server[SERVER_URL_INDEX]])
            count += 1
        print_table(title, columns, dataset)
        try:
            selection = int(input('Select a destination server (Enter number): ')) - 1
            if not selection in range(len(url_list)):
                raise Exception('Invalid Input.')
        except:
            continue
        if (selection) == url_list.index(option_other):
            url = input('Enter URL: ')
        else:
            url = url_list[selection][SERVER_URL_INDEX]

    # Get certificate file and validate that it exists, not that it's valid.
    cert = None
    while cert is None:
        cert_input = input('Do you have a certificate file for SSL verification? (Y/N): ')
        if 'n' in cert_input:
            output_message(INFO, 'SSL verification disabled.')
            cert = False
        else:
            cert_file = get_file('Select Certificate File', [['Cert Files', '*.cer *.crt']])
            if os.path.exists(cert_file):
                cert = cert_file

    # dict = {'file': filename, 'url': url, 'cert': cert}
    args = types.SimpleNamespace(xml=filename, url=url, cert=cert)
    return args


def get_credentials() -> dict:
    """
    Get credentails for HTTP authentication.

    Returns:
        dict: credential dictionary {b64, username, password}
    """

    credentials = {}
    if not sys.stdin.isatty():
        # git bash has some issues with std input and getpass,
        # if not in a terminal call with winpty then terminate on return.
        os.system('winpty python ' + ' '.join(sys.argv))
        sys.exit()
    else:
        user = input('Enter login: ')
        passwd = getpass.getpass()

        b64_credential = base64.b64encode(
            ('{}:{}'.format(user, passwd)).encode('ascii')
        ).decode('utf-8')

        credentials['b64'] = b64_credential
        credentials['username'] = user
        credentials['password'] = passwd
    return credentials


def get_file(title: str, filter: list) -> str:
    """
    Display a file dialog and ask the user the select their desired file.

    Args:
        title(str): Title for the file dialog window.
        filters(list): list of lists - names and extensions to filter for.
            Single filter: [['CSV files','*.csv']]
            Multiple selectable filters: [['CSV files','*.csv'],['Excel files','*.xls *.xlsx']]

    Returns:
        (str): Path and filename.
    """

    filename = ''
    while not os.path.exists(filename):
        import tkinter
        from tkinter.filedialog import askopenfilename
        root = tkinter.Tk()
        root.attributes('-topmost', True)
        root.withdraw()
        filename = askopenfilename(parent=root, title=title, filetypes=filter)
    return filename


def print_table(title: str, columns: list, dataset: list):
    """
    Print table header.
    -----------
       Title
    -----------
    col col col
    --- --- ---
    val val val
    -----------

    Args:
        columns (list): list of column headers.
        dataset (list): list of lists containing rows of data.
    """

    # Find column widths
    table_width = len(title)  # Initial table width will be title width
    column_widths = []
    for col in columns:  # Establish array
        column_widths.append(len(str(col)))
    for row in dataset:  # Populate array
        col_count = 0
        for col in row:
            if len(str(col)) > column_widths[col_count]:
                column_widths[col_count] = len(str(col))
            col_count += 1
    calculated_width = 0
    for width in column_widths:
        calculated_width += width
    calculated_width += len(columns) - 1  # Add one space gap between columns
    if calculated_width > table_width:
        table_width = calculated_width

    # Build table header
    table = ''
    table += '{}\n'.format('-' * table_width)
    table += '{:^{}}\n'.format(title, table_width)
    table += '{}\n'.format('-' * table_width)
    col_count = 0
    heading_separater = ''
    for column in columns:
        table += '{:^{}}'.format(column, column_widths[col_count])
        heading_separater += '{}'.format('-' * column_widths[col_count])
        if len(columns) > col_count + 1:
            table += ' '
            heading_separater += ' '
        else:
            table += '\n'
            heading_separater += '\n'
        col_count += 1
    table += heading_separater

    # Build table rows
    for row in dataset:
        col_count = 0
        for col in row:
            table += '{:{}}'.format(col, column_widths[col_count])
            if len(row) > col_count + 1:
                table += ' '
            else:
                table += '\n'
            col_count += 1
    print(table)


def output_message(severity: str, message: str):
    """
    Write message to log and console. Messages color coded to indicate severity on console.

    Args:
        severity: log level [info, warn, error]
        message: string to output.
    """

    colorama.init(autoreset=True)

    if severity == INFO:
        log.info(message)
        print(colorama.Fore.WHITE + '\n{}'.format(message))
    elif severity == WARNING:
        log.warning(message)
        print(colorama.Fore.YELLOW + '\n{}: {}'.format('WARNING', message))
    elif severity == ERROR:
        log.error(message)
        print(colorama.Fore.RED + '\n{}: {}'.format('ERROR', message))


def set_http_session(server: str, credentials: dict, certificate: str) -> requests.Session:
    """
    Create http session object.

    Args:
        server: URL to connect to
        credentials: Credentials dictionary. {b64:'', username:'', password:''}
        certificate: Certificate for SSL verification

    Returns:
        requests.Session() object
    """

    # Establish session
    http_session = requests.Session()
    # http_session.headers['Authorization'] = 'Basic {}'.format(credentials.get('b64'))
    headers = {
        "Authorization": "Basic {}".format(credentials.get('b64')),
        "Accept": "application/json",
        "Content-Type": "application/json"
    }
    for header in headers:
        http_session.headers[header] = headers.get(header)
    http_session.verify = certificate
    http_session.get(server)
    return http_session


def output_info(message: str):
    """
    Write same message to log and console.

    Args:
        message: string to output.
    """

    log.info(message)
    print(message)


def ask_yes_no(question: str) -> bool:
    """
    Ask a yes/no question until the user answers, and return True/False.

    Args:
        question: Question to ask user.

    Returns:
        bool
    """

    answer = False
    ask = ''
    while ('y' not in ask) and (not 'n' in ask):
        ask = (input(question)).lower()
    if 'y' in ask.lower():
        answer = True
    return answer


def validate_url(url: str, certificate: str) -> bool:
    """
    Check URL for a valid response. This only verifies that a resource is available.
    This function does not test authentication or validate that a REST path is valid.

    Args:
        url: Url for testing
        certificate: Certificate package to use for SSL/TLS verification.

    Returns:
        Bool: True if URL is accessible.
    """

    log.info('Validating URL = {}'.format(url))

    if not certificate:
        certificate = False
        disable_warnings(InsecureRequestWarning)
        log.warning('Certificate not provided, SSL Verification disabled.')

    is_valid = False
    if url is not None:
        try:
            rest_response = requests.get(url, verify=certificate)
            log.info('URL returned status code ({}).'.format(
                rest_response.status_code))
            is_valid = bool(rest_response.status_code == http.HTTPStatus.OK)
        except ConnectionError as error_message:
            log.error('Cannot reach {}, Error = {}'.format(url, error_message))
            print('Could not contact server: {}'.format(url))
    return is_valid


def read_users_from_xml(xml: etree._Element) -> dict:
    """
    Search XML file for user entities.
    User entry begins, <object class="ConfluenceUserImpl" package="com.atlassian.confluence.user">,
    and ends with a closing </object> tag. The element contains the user's key
    as well as the username and lower case username. The lowercase name is not used here.
    By adding users to a dictionary we garantee a unique list of users.

    Args:
        xml: xml data to search in.

    Returns:
        dict: {source_username:{source_key, target_username, target_key}}
    """

    users_dict = {}
    count = 0
    target_xpath = '//object[@class=\"ConfluenceUserImpl\"]'
    user_count = len(xml.xpath(target_xpath))
    log.info('Found {} user entries, parsing user data.'.format(user_count))

    progress_bar = IncrementalBar('Parsing users from xml', max=user_count)
    for element in xml.xpath(target_xpath):
        key = element.find('id').text  # First child element
        name = element.find('property').text  # Second child element

        if key not in users_dict.keys():
            users_dict[name] = {'source_key':key, 'target_username':None, 'target_key':None}
            log.info('user_dict, add {} = {}'.format(key, name))
            count += 1
        progress_bar.next()
    progress_bar.finish()

    return users_dict


def read_users_from_csv(filename: str) -> dict:
    """
    Get users in CSV file.

    Args:
        filename: path and/or filename containing the user table.

    Returns:
        dict: {source_username:{source_key, target_username, target_key}}
    """

    users_dict = {}

    with open(filename) as csv_file:
        log.info('Reading CSV file: {}'.format(filename))

        csv_data = []
        csv_reader = csv.reader(csv_file, delimiter=',')
        for row in csv_reader:
            csv_data.append(row)

        record_count = 0

        progress_bar = IncrementalBar('Parsing users from xml', max=len(csv_data))
        for user in csv_data:
            if csv_data.index(user) != 0:  # Ignore header row
                user_record = {
                    'source_key': user[1],
                    'target_username':user[2],
                    'target_key': user[3]
                    }
                users_dict[user[0]] = user_record
            record_count += 1
            progress_bar.next()
        progress_bar.finish()

        log.info('{} users read from csv.'.format(record_count - 1))
    return users_dict


def dict_to_csv(input_dict: dict, filename: str, name: str = ''):
    """
    Accepts a dictionary and outputs it to CSV.

	Args:
		input_dict: formatted dictionary data.
		filename: filename to export.
		name: string to append to filename.
    """

    # Get user table and set up backup
    input_path = os.path.split(filename)[0]
    input_file = os.path.split(filename)[1]
    if name != '':
        input_file = '{}.csv'.format(name)
    bakup_count = len(glob.glob1(input_path, '{}*.bak'.format(input_file)))
    backup_file = '{}.bak'.format(input_file)
    if bakup_count != 0:  # Add number to backup file if necessary.
        backup_file = '{}({}).bak'.format(input_file, bakup_count + 1)
    if os.path.exists(os.path.join(input_path, input_file)):
        source_file = os.path.join(input_path, input_file)
        target_file = os.path.join(input_path, backup_file)
        os.rename(source_file, target_file)
        log.info('backed up {} to {}'.format(source_file, target_file))
    output_file = os.path.join(input_path, input_file)

    # Prepare output
    try:
        with open(output_file, 'w', newline='') as csv_file:
            log.info('Writing users to csv: {}'.format(csv_file.name))
            csv_writer = csv.writer(
                    csv_file,
                    delimiter=',',
                    quotechar='"',
                    quoting=csv.QUOTE_MINIMAL
                )

            # Header row
            column_list = [
                    'source_username',
                    'source_key',
                    'target_username',
                    'target_key'
                ]
            csv_writer.writerow(column_list)

            # Body rows
            for key in input_dict:
                csv_writer.writerow( [
                    key, # Key = source_username
                    input_dict[key].get('source_key'),
                    input_dict[key].get('target_username'),
                    input_dict[key].get('target_key')
                    ] )

            # Write remap user entry if necessary
            # users = []
            # for key in input_dict:
            #     users.append(key)

            if "remap_user" not in input_dict.keys():
                csv_writer.writerow(
                        [
                        'remap_user',
                        '',
                        '<username>',
                        ''
                        ]
                    )
        output_info('User info written to output file: {}'.format(output_file))
    except PermissionError:
        log.error('Cannot access file: {}'.format(output_file))
        sys.exit('Cannot access file, file may be in use.')


def get_user_info(session: requests.Session, server: str, user: str, user_record: dict, lookup_field: str) -> dict:
    """
    Get confluence user record with matching key/username.

    Args:
        session: http session object to connect with.
        server: URL to connect to.
        user: user to search for.
        user_record: user record to update.
        lookup_field: lookup using key or username.

    Returns:
        dict containing updated user record.
    """

    rest_path = '/rest/api/user'
    lookup_value = None
    query_url = None

    if lookup_field == 'key':
        lookup_value = user_record.get('source_key')
        query_url = '{}{}?key={}'.format(server, rest_path, lookup_value)

    if lookup_field == 'username':
        if user_record.get('target_key') == '':
            if user_record.get('target_username') != '':
                lookup_value = user_record.get('target_username')
                query_url = '{}{}?username={}' \
                        .format(server, rest_path, lookup_value)
        else:
            log.info('Skipping, \'{}\', key already acquired.'.format(user))

    if not query_url is None:
        log.info('Submitting URL: {}'.format(query_url))

        for i in range(10):
            rest_response = session.get(query_url)
            log.info('loop ({}), rest_response: {}'.format(i, rest_response))
            if rest_response.status_code == 200:
                json_response = json.loads(rest_response.text)
                if lookup_field == 'key':
                    user_record.update(
                        {'full_name':json_response.get('displayName')}
                        )
                    log.info('Updated entry from key query = {}' \
                        .format(user_record))
                if lookup_field == 'username':
                    user_record.update(
                        {'target_key':json_response.get('userKey')}
                        )
                    log.info('Updated entry from username query = {}' \
                        .format(user_record))
                break
            elif rest_response.status_code == 404:
                log.warn('{}, {}, not found on server {}. HTTP response: {}'
                    .format(lookup_field, lookup_value, server,
                            rest_response.text))
            elif rest_response.status_code == 401:
                log.error('{}, {}, Invalid login, check Confluence {}.' \
                    'HTTP response: {}'
                    .format(lookup_field, lookup_value, server,
                            rest_response.text))
                sys.exit('Invalid login.')
            else:
                log.error('Error querying url: {}. HTTP response: {}'
                    .format(server, rest_response.text))
    return user_record


def read_xml(xml_file: str) -> etree._Element:
    """
    Read XML file

    Args:
        xml_file: input filename.

    Returns:
        lxml etree._Element containing the input xml.
    """

    xml_in_root = None
    if os.path.exists(xml_file):
        output_info('Reading XML file: {}'.format(xml_file))
        try:
            xml_parser = etree.XMLParser(huge_tree = True) # Added due to possible huge input
            xml_in_tree = etree.parse(xml_file, xml_parser)
            xml_in_root = xml_in_tree.getroot()
        except:
            print('Something went wrong reading the xml file.')
    return xml_in_root


def replace_user_elements(xml: etree._Element, target_xpath: str, users: dict, remap: bool) -> etree._Element:
    """
    Update the user entries in the XML file. There must be only one entry per user.

    This function must run before updating user key elements or users will not be created properly.

    Args:
        xml: input xml.
        target_xpath: search path.
        users: dict of users
        remap: perform a remap or not

    Returns:
        Updated XML
    """

    log.info('Parsing user elements')
    for element in xml.xpath(target_xpath):
        user_id = None
        for child in element.iterchildren():
            if child.get('name') == 'key': # Key is first child element
                for user_index in users:
                    if child.text == users[user_index].get('source_key'):
                        if not users[user_index].get('target_key') == '':
                            user_id = user_index
                            child.text = users[user_id].get('target_key')
                            break
            elif (child.get('name') == 'name' and not user_id is None):
                child.text = users[user_id].get('target_username')
            elif (child.get('name') == 'lowerName' and not user_id is None):
                child.text = (users[user_id].get('target_username')).lower()
        if user_id is None and not remap:
            log.warn('Removing duplicate user entry for user {}' \
                    .format(element[2].text))
            element.getparent().remove(element)
    return xml


def update_user_key_elements(xml: etree._Element, target_xpath: str, users: dict, remap: bool) -> etree._Element:
    """
    Find and replace user keys.

    Args:
        xml: input xml.
        target_xpath: search path.
        users: dict of users
        remap: perform a remap or not

    Returns:
        Updated XML.
    """

    log.info('Updating user keys.')

    bar = IncrementalBar('Updating user keys', max=len(xml.xpath(target_xpath)))
    for element in xml.xpath(target_xpath):
        for user_index in users:
            if element.text == users[user_index].get('source_key'):
                if not users[user_index].get('target_key') == '':
                    element.text = users[user_index].get('target_key')
                else:
                    element.text = users['remap_user'].get('target_key')
        bar.next()
    bar.finish()
    log.info('Finished updating user keys.')
    return xml


def update_cdata_elements(xml: etree._Element) -> etree._Element:
    """
    Tag elements in list as CDATA in XML output.

    Args:
        xml: input xml.

    Returns:
        Updated XML.
    """

    log.info('Formatting CDATA elements.')
    # Attribute names represented as CDATA
    cdata_attribute_names = [
        'allUsersSubject',
        'body',
        'code',
        'contentStatus',
        'context',
        'creator',
        'destinationPageTitle',
        'destinationSpaceKey',
        'entityName',
        'group',
        'groupName',
        'key',
        'labelableType',
        'lastModifier',
        'lowerDestinationPageTitle',
        'lowerDestinationSpaceKey',
        'lowerKey',
        'lowerName',
        'lowerTitle',
        'lowerUrl',
        'name',
        'namespace',
        'owningUser',
        'pluginModuleKey',
        'pluginVersion',
        'receiver',
        'relationName',
        'sourceContent',
        'stringVal',
        'stringValue',
        'textVal',
        'title',
        'type',
        'url',
        'user',
        'userSubject',
        'value',
        'versionComment'
        ]

    bar = IncrementalBar('Formatting CDATA elements', max=sum(1 for _ in xml.iter("*")))
    for element in xml.iter():
        if element.get('name') in cdata_attribute_names:
            if not element.text is None:
                element.text = etree.CDATA(element.text)
        bar.next()
    bar.finish()
    log.info('Finished updating CDATA elements.')
    return xml


def replace_mention(xml: etree._Element, target_xpath: str, users: dict) -> etree._Element:
    """
    Find and replace mention links.

    Args:
        xml: input xml.
        target_xpath: search path.
        users: dict of users
        remap: perform a remap or not

    Returns:
        Updated XML.
    """

    log.info('Updating @mentions.')
    progress_bar = IncrementalBar('Updating mentions',max=len(xml.xpath(target_xpath)))
    for element in xml.xpath(target_xpath):
        for user in users:
            if user != 'remap_user':  # Do not include remap user
                if users[user].get('source_key') in element.text:
                    if not users[user].get('target_key') == '':
                        element.text = (element.text).replace(
                            users[user].get('source_key'),
                            users[user].get('target_key')
                        )
                    else:
                        if not users.get('remap_user') is None:
                            element.text = (element.text).replace(
                                users[user].get('source_key'),
                                users['remap_user'].get('target_key')
                                )
                        else:
                            log.info('Line {}, keeping user {}.'.format(
                                element.sourceline,
                                users[user].get('source_key')
                                ))
                            # No change to element.text
        progress_bar.next()
    progress_bar.finish()
    log.info('Finished updating mentions.')
    return xml


def replace_links(xml: etree._Element, target_xpath: str, target_url: str) -> etree._Element:
    """
    Find and replace mention links.

    Args:
        xml: input xml.
        target_xpath: search path.
        users: dict of users
        remap: perform a remap or not

    Returns:
        Updated XML.
    """

    log.info('Updating links.')
    bar = IncrementalBar('Updating links',max=len(xml.xpath(target_xpath)))
    link_count = 0
    for element in xml.xpath(target_xpath):
        if '<a href=' in element.text:
            link_count += 1
    if link_count > 0:
        source_url = input('HTML links found. Enter source confluence URL: ')
        for element in xml.xpath(target_xpath):
            element.text = (element.text).replace(source_url, target_url)
            bar.next()
        bar.finish()
        log.info('Finished updating links.')
    else:
        log.info('No links found in XML.')
    return xml


def replace_space_key(xml: etree._Element, input_file: str) -> etree._Element:
    """
    Replace a space's key.

    Args:
        xml: Input xml.
        input_file: File to help determine path.

    Returns:
        Updated XML
    """

    search_xpath = '//object[@class=\"Space\"]'
    space_key = None
    new_key = None

    # Replace space key
    for element in xml.xpath(search_xpath):
        for child in element.iterfind('property'):  # Find existing key
            if child.get('name') == 'key':
                space_key = child.text
                new_key = (input('Found space key: {}, enter new key: '
                        .format(space_key))
                    ).upper()
                if not new_key is None:
                    log.info('Found space with key {}, replacing with {}' \
                            .format(space_key, new_key))
                    child.text = new_key
                else:
                    log.error('invalid key entered')
                    sys.exit('Invalid key entered. No changes will be made.')

            if child.get('name') == 'lowerKey':
                child.text = new_key.lower()

    # Find all "spaceKey":"<key>" references and re-key them.
    #<object class="BucketPropertySetItem" package="bucket.user.propertyset">
    search_xpath = '//object[@class=\"BucketPropertySetItem\"]'
    for element in xml.xpath(search_xpath):
        for child in element.iterfind('property'):  # Find existing key
            if child.get('name') == 'textVal':
                if not child.text is None:
                    if 'spaceKey' in child.text:
                        child.text = (child.text).replace(
                                '\"spaceKey\":\"{}\"'.format(space_key),
                                '\"spaceKey\":\"{}\"'.format(new_key)
                            )

    # Check for sidebar.nav
    search_xpath = '//object[@class=\"ConfluenceBandanaRecord\"]'
    for element in xml.xpath(search_xpath):
        for child in element.iterfind('property'):
            if child.get('name') == 'context':
                child.text = new_key

    return xml


def write_descriptor_file(xml_data: etree._Element, filename: str):
    """
    Update key in descriptor file.

    Args:
        xml_data: Content of xml file read into etree._Element.
        filename: filename of source xml file, used to locate descriptor.
    """

    # Locate space key
    search_xpath = '//object[@class=\"Space\"]'
    space_key = None
    for element in xml_data.xpath(search_xpath):
        for child in element.iterfind('property'):  # Find existing key
            if child.get('name') == 'key':
                space_key = child.text

    # Get exportDescriptor.properties file
    input_file = '{}/exportDescriptor.properties'.format(os.path.split(filename)[0])
    bak_count = len(glob.glob1(os.path.split(input_file)[0], 'exportDescriptor.properties*.bak'))
    backup_file = '{}.bak'.format(input_file)
    if bak_count != 0:
        backup_file = '{}({}).bak'.format(input_file, bak_count + 1)
    os.rename(input_file, backup_file)
    output_file = input_file

    # Replace key in descriptor file
    with open(output_file, 'a') as outfile:
        with open(backup_file, 'r') as infile:
            for line in infile:
                if 'spaceKey' in line:
                    outfile.write('spaceKey={}\n'.format(space_key))
                    log.info('Replaced key in exportDescriptor.properties')
                else:
                    outfile.write(line)
    output_info('exportDescriptor.properties written to output file: {}'.format(output_file))


def write_xml(xml_data: etree._Element, filename: str):
    """
    Write output to XML file.

    Args:
        xml_data: Content of xml file read into etree._Element.
        filename: Absolute path to input xml file.
    Returns:
        etree._Element: updated xml content.
    """

    output_info('Writing XML to file.')
    input_path = os.path.split(filename)[0]
    input_file = os.path.split(filename)[1]
    bakup_count = len(glob.glob1(input_path, '{}*.bak'.format(input_file)))
    backup_file = '{}.bak'.format(input_file)
    if bakup_count != 0:  # Add number to backup file if necessary.
        backup_file = '{}({}).bak'.format(input_file, bakup_count + 1)
    os.rename(filename, os.path.join(input_path, backup_file))
    output_file = filename

    output = etree.tostring(xml_data, pretty_print=True, encoding="UTF-8",
             xml_declaration=True)

    try:
        with open(output_file, 'wb') as xml_file:
            xml_file.write(output)
    except IOError as e:
        log.error('IOError: {}'.format(e))
    except OSError as e:
        log.error('Cannot access file: {}'.format(output_file))
    finally:
        output_info('XML written to output file: {}'.format(output_file))


def xml_cleanup(xml_data: etree._Element) -> etree._Element:
    """
    Check for and remove duplicate entities.

    Args:
        xml_data: content of xml file read into etree._Element.

    Returns:
        etree._Element: updated xml content.
    """

    # Search for and remove duplicate relationship elements.
    relationships = {}
    search_xpath = '//object[@class=\"User2ContentRelationEntity\"]'
    for element in xml_data.xpath(search_xpath):
        property_target_content_id = None
        property_source_content_id = None
        property_relationname_text = None

        for child in element.iterchildren():
            if len(child) == 0:
                if child.get('name') == 'relationName':
                    property_relationname_text = child.text
            else:
                for grandchild in child.iterchildren():
                    if child.get('name') == 'targetContent' and \
                            grandchild.get('name') == 'id':
                        property_target_content_id = grandchild.text
                    if child.get('name') == 'sourceContent' and \
                            grandchild.get('name') == 'key':
                        property_source_content_id = grandchild.text

        if property_target_content_id and property_source_content_id and property_relationname_text:
            if not property_target_content_id in relationships:
                # New targetContent id
                relationships[property_target_content_id] = \
                        {property_relationname_text: \
                        [property_source_content_id]}
            else:
                # Existing targetContent id
                if not property_relationname_text in \
                        relationships[property_target_content_id]:
                    # New relationName
                    relationships[property_target_content_id] \
                            [property_relationname_text] = \
                            [property_source_content_id]
                else:  # Existing relationName
                    if not property_source_content_id in \
                            relationships[property_target_content_id] \
                            [property_relationname_text]:
                        # New user key
                        relationships[property_target_content_id] \
                                [property_relationname_text].append \
                                (property_source_content_id)
                    else:  # Existing user key
                        # Delete entity
                        # add log entry for deletions
                        element.getparent().remove(element)
        else:
            output_info('Error processing element {} at {}'.format(element, element.sourceline))
    return xml_data


def remove_duplicate_users(xml_data: etree._Element) -> etree._Element:
    """
    Search for all users. Add each user's key to a dict. If a user is already
    in the list, it's a duplicate. Delete any duplicate users.

    Args:
        xml_data: content of xml file read into etree._Element.

    Returns:
        etree._Element: updated xml content.
    """

    users = {}
    search_xpath = '//object[@class=\"ConfluenceUserImpl\"]'
    for element in xml_data.xpath(search_xpath):
        for child in element.iterchildren():
            if len(child) == 0:
                if child.get('name') == 'key':
                    if not child.text in users:
                        users[child.text] = None
                    else:
                        element.getparent().remove(element)
                        log.info('Removing duplicate entry for {}' \
                                .format(child.text))
    return xml_data


def remove_page_restrictions(xml_data: etree._Element) -> etree._Element:
    """
    Search for any page restrictions and delete them. Page restrictions do not import correctly
    and will prevent permissions from being applied properly to the target instance.

    Args:
        xml_data: content of xml file read into etree._Element.

    Returns:
        etree._Element: updated xml content.
    """

    search_xpath = '//object[@class=\"ContentPermissionSet\"]'
    for element in xml_data.xpath(search_xpath):
        element.getparent().remove(element)
        log.info('Removing page restriction entry on line, {}'.format(element.sourceline))
    return xml_data


def finish_message(start_time: float):
    """
    Display finish message and elapsed run time

    Args:
        start_time: Time script started
    """

    elapsed_time = time.time() - start_time
    hours = divmod(elapsed_time, 3600)
    minutes = divmod(hours[1], 60)
    seconds = minutes[1]
    finish_message = '{} finished, elapsed time (h:m:s): {:0>2}:{:0>2}:{:0>2}\n'\
        .format(os.path.basename(__file__), int(hours[0]), int(minutes[0]), int(seconds))
    log.info(finish_message)
    print(finish_message)
