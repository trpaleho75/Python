# Installation

*Prior to running pip install, configure pip to download packages from SRES:
Follow Instructions
[HERE](https://git.web.boeing.com/artifactory/documentation/-/blob/master/python/README.md)*

| Dependency      | Tested Version |
| --------------- | -------------- |
| requests        | 2.25.1         |

~~~Shell
pip install requests
~~~

Specific versions of libraries can be installed using "[library]==[version]" syntax:

~~~Shell
pip install requests==2.25.1
~~~

## Usage

~~~Shell
python loadtest.py -t[--token] <Jira Personal Access Token>
~~~

## Output

~~~Shell
-----------------------------------------------
    Metrics Summary (all times in seconds)
-----------------------------------------------
    Operation     Count Avg  Min   Max   Total
----------------- ----- ---- ---- ----- -------
Create Issues     440   0.74 0.18 1.69  327.47
Add Attachments   421   4.33 0.00 10.95 1823.43
Add Comments      428   0.42 0.16 1.44  178.12
Link Issues       459   0.35 0.16 1.23  159.67
Transition Issues 241   0.45 0.17 1.06  109.51
Run Queries       440   2.08 0.17 10.67 916.52
Run Time: 00:05:05
~~~
